# KasirCI
Tugas pembuatan aplikasi kasir / Point of Sales
build dengan CodeIgniter
