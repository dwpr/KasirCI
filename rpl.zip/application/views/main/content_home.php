<div class="col-sm-9 col-md-10 main">
<h2 class="alert alert-info" align="center" style="padding-bottom:15px;">Selamat Datang di Toko Buku ABC</h2>
<img class="img-responsive" src="<?php echo base_url('assets/img/abc_bookshop.PNG');?>">
</div>